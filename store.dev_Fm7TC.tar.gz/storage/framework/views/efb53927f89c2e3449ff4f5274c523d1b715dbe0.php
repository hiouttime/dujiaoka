<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <h4 class="page-title"><?php echo e(isset($title) ? __('article.article') : __('article.total'), false); ?></h4>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="card card-body">
            <?php if(empty($content)): ?>
            <div class="tab-pane show active" id="bordered-tabs-preview">
                <ul class="nav nav-tabs nav-bordered mb-3">
                    <li class="nav-item">
                        <a href="#all" data-toggle="tab" aria-expanded="false" class="nav-link active">
                            <span>全部文章</span>
                        </a>
                    </li>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a href="#category<?php echo e($index, false); ?>" data-toggle="tab" aria-expanded="false" class="nav-link">
                            <span><?php echo e($key, false); ?></span>
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="tab-content articles">
                    <div class="tab-pane show active" id="all">
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $one; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <h2><?php echo e($article->title, false); ?></h5>
                                    <p><?php echo e($article->summary, false); ?></p>
                                    <a href="<?php echo e(url('article/'.$article->link), false); ?>">阅读更多</a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane" id="category<?php echo e($loop->index, false); ?>">
                        <?php $__currentLoopData = $one; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <h2><?php echo e($article->title, false); ?></h5>
                                <p><?php echo e($article->summary, false); ?></p>
                                <a href="<?php echo e(url('article/'.$article->link), false); ?>">阅读更多</a>
                            </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>                                          
            </div>
            <?php else: ?>
                <div class="row articles">
                    <h3><?php echo e($title, false); ?></h3>
                </div>
             <hr/>
            <?php echo $content; ?>

            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('hyper.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/storedev/resources/views/hyper/static_pages/article.blade.php ENDPATH**/ ?>