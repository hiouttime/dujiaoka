<?php if($grid->allowPagination()): ?>
    <div class="box-footer d-block clearfix ">
        <?php echo $grid->paginator()->render(); ?>

    </div>
<?php endif; ?>
<?php /**PATH /www/wwwroot/teststore/vendor/dcat/laravel-admin/src/../resources/views/grid/table-pagination.blade.php ENDPATH**/ ?>