<script src="/assets/unicorn/js/jquery-3.6.0.min.js"></script>
<script src="/assets/unicorn/js/bootstrap.min.js"></script>
<script src="/assets/unicorn/js/main.js"></script><?php /**PATH /www/wwwroot/storedev/resources/views/unicorn/layouts/_script.blade.php ENDPATH**/ ?>