<!-- footer start-->
<footer class="footer p-3">
    <div class="row">
        <div class="col-12 text-center">
            <div class="author">
                Powered by：<a href="https://github.com/outtimes/dujiaoka">@独角数卡</a>
            </div>
            <div class="custom">
                <?php echo dujiaoka_config_get('footer'); ?>

            </div>
        </div>
    </div>
</footer>
<!-- footer end-->
<?php /**PATH /www/wwwroot/teststore/resources/views/unicorn/layouts/_footer.blade.php ENDPATH**/ ?>