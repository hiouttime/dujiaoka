<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <h4 class="page-title"><?php echo e(isset($title) ? __('article.article') : __('article.total'), false); ?></h4>
        </div>
    </div>
</div>
<div class="card card-body">
    <?php if(empty($content)): ?>
    <table class="table article-list">
    <thead>
        <tr>
            <th><?php echo e(__('article.fields.title'), false); ?></th>
            <th><?php echo e(__('admin.updated_at'), false); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <div>
                    <a href="<?php echo e(url("/article/{$article->link}"), false); ?>"><?php echo e($article->title, false); ?></a>
                </div>
                <div class="summary"><?php echo e($article->getSummary(), false); ?></div>
            </td>
            <td><?php echo e($article->updated_at, false); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
    <?php else: ?>
        <div class="row articles">
            <h3><?php echo e($title, false); ?></h3>
        </div>
        <hr/>
        <?php echo $content; ?>

    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('hyper.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/teststore/resources/views/hyper/static_pages/article.blade.php ENDPATH**/ ?>