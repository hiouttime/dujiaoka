<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <div class="app-search">
                    <div class="position-relative">
                        <input type="text" class="form-control" id="search" placeholder="<?php echo e(__('hyper.home_search_box'), false); ?>">
                        <span class="uil-search"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="card card-body">
    <h4 class="page-title d-md-block">
        <?php echo e(__('hyper.notice_announcement'), false); ?>

    </h4>
        <?php echo dujiaoka_config_get('notice'); ?>

</div>
<div class="nav nav-list">
    <a href="#group-all" class="tab-link active" data-bs-toggle="tab" aria-expanded="false" role="tab" data-toggle="tab">
        <span class="tab-title">
        
        <?php echo e(__('hyper.home_whole'), false); ?>

        </span>
        <div class="img-checkmark">
            <img src="/assets/hyper/images/check.png">
        </div>
    </a>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="#group-<?php echo e($group['id'], false); ?>" class="tab-link" data-bs-toggle="tab" aria-expanded="false" role="tab" data-toggle="tab">
        <span class="tab-title">
            <?php echo e($group['gp_name'], false); ?>

        </span>
        <div class="img-checkmark">
            <img src="/assets/hyper/images/check.png">
        </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="tab-content">
    <div class="tab-pane active" id="group-all">
        <div class="hyper-wrapper">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $group['goods']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url("/buy/{$goods['id']}"), false); ?>" class="home-card category <?php if($goods['in_stock'] <= 0): ?> ribbon-box <?php endif; ?>">
                    <?php if($goods['in_stock'] <= 0): ?>
                    <div class="ribbon-two ribbon-two-danger">
                            
                            <span><?php echo e(__('hyper.home_out_of_stock'), false); ?></span>
                        </div>
                    <?php endif; ?>
                        <img class="home-img" src="/assets/hyper/images/loading.gif" data-src="<?php echo e(picture_ulr($goods['picture']), false); ?>">
                        <div class="flex">
                            <p class="name">
                                <?php echo e($goods['gd_name'], false); ?>

                            </p>
                            <div class="price">
                                <?php echo e(__('hyper.global_currency'), false); ?><b><?php echo e($goods['actual_price'], false); ?></b>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="tab-pane" id="group-<?php echo e($group['id'], false); ?>">
            <div class="hyper-wrapper">
                <?php $__currentLoopData = $group['goods']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($goods['in_stock'] > 0): ?>
                    <a href="<?php echo e(url("/buy/{$goods['id']}"), false); ?>" class="home-card category">
                    <?php else: ?>
                    <a href="javascript:void(0);" onclick="sell_out_tip()" class="home-card category ribbon-box">
                        <div class="ribbon-two ribbon-two-danger">
                            
                            <span><?php echo e(__('hyper.home_out_of_stock'), false); ?></span>
                        </div>
                    <?php endif; ?>
                        <img class="home-img" src="/assets/hyper/images/loading.gif" data-src="<?php echo e(picture_ulr($goods['picture']), false); ?>">
                        <div class="flex">
                            <p class="name">
                                <?php echo e($goods['gd_name'], false); ?>

                            </p>
                            <div class="price">
                                <?php echo e(__('hyper.global_currency'), false); ?><b><?php echo e($goods['actual_price'], false); ?></b>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="row">
    <div class="col-12">
    <div class="page-title-box">
        <h4 class="page-title d-md-block">
            <?php echo e(__('article.total'), false); ?>

        </h4>
    </div>
    </div>
</div>
<div class="article-grid">
<div class="card card-body">
    <div class="article-title">
        <h4><?php echo e(__('article.newest'), false); ?></h4>
        <a href="/article"><?php echo e(__('article.more'), false); ?>>></a>
    </div>
    <table class="articles">
        <tbody>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(url("/article/{$article->link}"), false); ?>"><?php echo e($article->title, false); ?></a></td>
                <td><?php echo e($article->updated_at, false); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="card card-body">
    <div class="article-title">
        <h4><?php echo e(__('article.recommend'), false); ?></h4>
        <a href="/article"><?php echo e(__('article.more'), false); ?>>></a>
    </div>
    <table class="articles">
        <tbody>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(url("/article/{$article->link}"), false); ?>"><?php echo e($article->title, false); ?></a></td>
                <td><?php echo e($article->updated_at, false); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>
    
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('js'); ?>
<script>
    $("#search").on("input",function(e){
        var txt = $("#search").val();
        if($.trim(txt)!="") {
            $(".category").hide().filter(":contains('"+txt+"')").show();
        } else {
            $(".category").show();
        }
    });
    function sell_out_tip() {
        $.NotificationApp.send("<?php echo e(__('hyper.home_tip'), false); ?>","<?php echo e(__('hyper.home_sell_out_tip'), false); ?>","top-center","rgba(0,0,0,0.2)","info");
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('hyper.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/teststore/resources/views/hyper/static_pages/home.blade.php ENDPATH**/ ?>