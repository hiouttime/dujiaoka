<?php echo $body; ?>

<?php /**PATH /www/wwwroot/teststore/resources/views/email/mail.blade.php ENDPATH**/ ?>