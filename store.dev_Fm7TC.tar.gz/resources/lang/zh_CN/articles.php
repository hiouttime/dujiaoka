<?php
return [
    'link' => '文章链接'
    ];