<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
class CreateAdminExtensionsTable extends Migration {
    public function getConnection() {
        return $this->config('database.connection') ? : config('database.default');
    }
    
    public function config($key)
    {
        return config('admin.'.$key);
    }
    
    public function up() {
        $name = $this->config('database.extensions_table') ? : 'admin_extensions';
        if (!Schema::hasTable($name)) {
            Schema::create($name, function (Blueprint $table) {
                $table->increments('id')->unsigned();
                $table->string('name', 100)->unique();
                $table->string('version', 20)->default('');
                $table->tinyInteger('is_enabled')->default(0);
                $table->text('options')->nullable();
                $table->timestamps();
                $table->engine = 'InnoDB';
            });
        }
        $name = $this->config('database.extension_histories_table') ? : 'admin_extension_histories';
        if (!Schema::hasTable($name)) {
            Schema::create($name, function (Blueprint $table) {
                $table->bigIncrements('id')->unsigned();
                $table->string('name', 100);
                $table->tinyInteger('type')->default(1);
                $table->string('version', 20)->default(0);
                $table->text('detail')->nullable();
                $table->index('name');
                $table->timestamps();
                $table->engine = 'InnoDB';
            });
        }
    }
    public function down() {
        Schema::dropIfExists('admin_operation_log');
    }
}
