<?php
return [
    'options'=>[
        'situations'=>[
            'add_product' => '新增商品'
        ]]
    ];