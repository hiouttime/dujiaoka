<?php

namespace ProductsNotice;

use Dcat\Admin\Extend\Setting as Form;

class Setting extends Form
{
    public function title()
    {
        return "设置推送";
    }
    
    public function form()
    {
        $this->text('license','授权码')->required();
        $this->text('tg_bot_token','Telegram机器人密钥')->required();
        $this->text('tg_proxy','Telegram API代理');
        $this->text('target_channel','发送消息的频道用户名')->required();
        $this->text('button_text','消息购买按钮文案')->default('🛒立即购买')->required();
        $this->text('unit','价格单位')->default('元')->required();
        $this->multipleSelect('situations','要发送消息的情况')
            ->options(ProductsNoticeServiceProvider::$situations)
            ->default(array_slice(ProductsNoticeServiceProvider::$situations,0,3))
            ->required();
    }
}
