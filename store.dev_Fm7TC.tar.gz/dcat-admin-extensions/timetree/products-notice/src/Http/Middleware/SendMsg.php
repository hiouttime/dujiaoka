<?php
/*
* 压根没加密也没激活码的逻辑
* 佛系更新插件销量纯看看天意
* 看得懂的话可以自己定义消息
* 如果你真想的话拿去倒卖也行
*/
namespace ProductsNotice\Http\Middleware;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use ProductsNotice\ProductsNoticeServiceProvider;
class SendMsg {
	protected $tg_api = "https://api.telegram.org/";
	protected $titleMap = [
	        "replenishment" => "补货通知 🛎",
	        "add_product" => "上新通知 🆕",
	        "reduction" => "降价通知 📉️",
	        "increase" => "涨价通知 📈"
	        ];
    protected $listenMethod = ["POST","PUT"];
    public function handle(Request $request, \Closure $next) {
		if(!in_array($request->method(),$this->listenMethod))
			return $next($request);
		
		$type = null;
		$moneyUnit = ProductsNoticeServiceProvider::setting('unit');
		$input = $request->input();
		$path = explode("/",$request->path(),2)[1];
		switch ($path) {
			case 'dcat-api/form': # 导入卡密
			    if ($input['_form_'] == 'App\Admin\Forms\ImportCarmis') {
				    if (!empty($input['carmis_txt'])) $carmis = Storage::disk('public')->get($input['carmis_txt']);
				    if (!empty($input['carmis_list'])) $carmis = $input['carmis_list'];
				    $carmis = explode(PHP_EOL, $carmis);
				    $carmis = array_unique($carmis);
				    $count = 0;
				    foreach ($carmis as $carmi) if (trim($carmi) != '') $count++;
				    $goodId = $input['goods_id'];
				    $goodName = app('Service\GoodsService')->detail($goodId)->gd_name;
				    $more = "补货数量：*".$count."个*";
				    $type = "replenishment";
			}
			break;
			case 'carmis': # 添加卡密
			    if(array_key_exists('_form_',$input)) break;
			    $goodId = $input['goods_id'];
			    $goodName = app('Service\GoodsService')->detail($goodId)->gd_name;
			    $more = "补货数量：*1个*";
			    $type = "replenishment";
			break;
			case 'goods':# 添加商品
			    if(!array_key_exists('gd_name',$input)) break;
			    $goodName = $input['gd_name'];
			    $more = "商品描述：".$input['gd_description']."\n售价：*".$input['sell_price'].$moneyUnit."*";
			    $type = "add_product";
			break;
			default:
			    if(strpos($request->path(),'admin/goods/') === 0){
			        if(!array_key_exists('actual_price',$input)) break;
			        $goodId = explode('admin/goods/',$request->path(),2)[1];
			        $goodInfo = app('Service\GoodsService')->detail($goodId);
			        $goodName = $goodInfo->gd_name;
			        $curPrice = floatval($goodInfo->actual_price);
			        $newPrice = floatval($input['actual_price']);
			        $diffPrice = $newPrice - $curPrice;
			        $more = "售价：*".$newPrice.$moneyUnit."*\n";
			        if($diffPrice > 0){
			             $type = "increase";
			             $more.="涨价：*".$diffPrice.$moneyUnit."* ⬆️";
			        }
			        if($diffPrice < 0) {
			            $type = "reduction";
			            $more.="降价：*".abs($diffPrice).$moneyUnit."* ⬇️";
			        }
			    }
			break;
		}
		$response = $next($request);
		if(!isset($response->original['status']))//错误正常处理
		    return $response;
		if ($type && $response->original['status'] && $this->checkEnable($type)) {
			$msg = "\#" . $this->titleMap[$type] . "\n商品名称：*" . $goodName . "*\n";
			$msg.=$more;
			$msg = str_replace(['.','|'],['\\.','\\|'],$msg);
			if($type == "add_product") {
				$good = DB::table('goods')->orderBy('id', 'desc')->first();
				$goodId = $good->id;
			}
			$button = ["inline_keyboard" => [[["text" => ProductsNoticeServiceProvider::setting('button_text'), "url" => url("/buy/" . $goodId) ]]]];
			if(!empty(ProductsNoticeServiceProvider::setting('tg_proxy')))
                $this->tg_api = ProductsNoticeServiceProvider::setting('tg_proxy');
			$send = [
                        "chat_id" => ProductsNoticeServiceProvider::setting('target_channel'),
			            "text" => $msg,
			            "parse_mode" => "MarkdownV2",
			            "reply_markup" => json_encode($button),
			            "protect_content" => true
			        ];
			@file_get_contents($this->tg_api ."bot" . ProductsNoticeServiceProvider::setting('tg_bot_token') . "/sendMessage?".http_build_query($send),false,stream_context_create(['http'=>['timeout' => 1]]));
		}
		return $response;
	}
	
	private function checkEnable($method){ //判断是否启用了这项推送
	    $config = ProductsNoticeServiceProvider::setting('situations');
	    if(empty($config)) return false;
	    $allows = ProductsNoticeServiceProvider::$situations;
	    foreach ($config as $one)
	        if($allows[intval($one)] == $method)
	            return true;
        return false;
	}
}