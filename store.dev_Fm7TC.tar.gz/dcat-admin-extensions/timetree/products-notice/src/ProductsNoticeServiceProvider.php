<?php

namespace ProductsNotice;

use Dcat\Admin\Extend\ServiceProvider;
use Dcat\Admin\Admin;

class ProductsNoticeServiceProvider extends ServiceProvider
{
    static public $situations = ["add_product","replenishment","reduction","increase"];
	protected $middleware = [
        'middle' => [
            Http\Middleware\SendMsg::class,
        ],
    ];


	public function init()
	{
		parent::init();
	}

	public function settingForm()
	{
		return new Setting($this);
	}
}
