<?php

return [
    '1.0.0' => [
        'Initialize extension.',
    ],
];
