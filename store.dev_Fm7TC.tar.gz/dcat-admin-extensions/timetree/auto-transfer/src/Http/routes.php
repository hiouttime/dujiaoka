<?php

use TimeTree\AutoTransfer\Http\Controllers;
use Illuminate\Support\Facades\Route;

Route::get('auto-transfer', Controllers\AutoTransferController::class.'@index');