<div class="extension-demo">
	Welcome to dcat-admin !
</div>

<style>
	.extension-demo {
		color: @primary;
	}
</style>

<script require="@timetree.auto-transfer">
	$('.extension-demo').extensionDemo();
</script>
